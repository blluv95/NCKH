      /**
      * Created by BaoADR01 on 3/3/2016.
      */
      Meteor.startup(function () {
        console.log('Server started');
        // #Storing Data -> Adding example posts
        if(NhaXe.find().count() === 0) {
          console.log('Adding dummy posts');
          var dataNhaXe = [
            {
              MaNhaXe: 'NX01',
                TenNhaXe: 'Gia Tặng',
              DiaChi: 'Nam Định',
              DienThoai: '01668082122',
            },
            {
              MaNhaXe: 'NX02',
                TenNhaXe: 'Phương Trang',
              DiaChi: 'Hải Dương',
              DienThoai: '097623133',
            },
            {
              MaNhaXe: 'NX03',
              TenNhaXe: 'Minh Phước',
              DiaChi: 'Thái Bình',
              DienThoai: '01248542161',
            }
          ];
          // we add the dummyPosts to our database
          _.each(dataNhaXe, function(post){
            NhaXe.insert(post);
          });
        }
        //--------------------------------------------------------------------------------------------

        if(Tuyen.find().count() === 0) {
          console.log('Adding Tuyen');
          var TUYEN=[
            {
              MaTuyen:'TUYEN01',
              TenTuyen:'THÁI BÌNH - VINH',
              MaNhaXe:'NX01'
            },
            {
              MaTuyen:'TUYEN02',
              TenTuyen:'THAI BÌNH - QUẢNG NINH',
              MaNhaXe:'NX01'
            },    {
              MaTuyen:'TUYEN03',
              TenTuyen:'THÁI BÌNH - HÀ NỘI',
              MaNhaXe:'NX02'
            },{
              MaTuyen:'TUYEN04',
              TenTuyen:'HẢI DƯƠNG - VINH',
              MaNhaXe:'NX03'
            }
          ];

          _.each(TUYEN, function(post){
            Tuyen.insert(post);
          });
        }
        //----------------------------------------------------------------------------------------
        if(Diemdung_TG.find().count() === 0) {
          console.log('Adding Diemdung_TG');
        var DiemUNG_THOIGIAN=[
          {
            MaDiem : 'Diem01',
            ThoiGian : '10:25:00'
          },{
            MaDiem : 'Diem02',
            ThoiGian : '11:10:00'
          },{
            MaDiem : 'Diem03',
            ThoiGian : '11:55:00'
          },{
            MaDiem : 'Diem04',
            ThoiGian : '13:40:00'
          },{
            MaDiem : 'Diem05',
            ThoiGian : '16:40:00'
          },{
            MaDiem : 'Diem06',
            ThoiGian : '10:45:00'
          },{
            MaDiem : 'Diem07',
            ThoiGian : '11:20:00'
          },{
            MaDiem : 'Diem08',
            ThoiGian : '12:15:00'
          },{
            MaDiem : 'Diem09',
            ThoiGian : '14:00:00'
          },{
            MaDiem : 'Diem10',
            ThoiGian : '17:00:00'
          }
        ];
        _.each(DiemUNG_THOIGIAN, function(post){
          Diemdung_TG.insert(post);
        });
      }
//---------------------------------------------------------------------------------
if(DiemDung.find().count() === 0) {
  console.log('Adding DiemDung');
        var DiemDUNG=[
          {
            MaDiem :'Diem01',
            MaChuyen : 'CHUYEN01',
            TenDiem : 'Thái Bình',
            STT : 1
          },{
            MaDiem :'Diem02',
            MaChuyen : 'CHUYEN01',
            TenDiem : 'Nam Định',
            STT : 2
          },{
            MaDiem :'Diem03',
            MaChuyen : 'CHUYEN01',
            TenDiem : 'Đại lý Rừng và Biển',
            STT : 3
          },{
            MaDiem :'Diem04',
            MaChuyen : 'CHUYEN01',
            TenDiem : 'Văn phòng Thanh Hóa',
            STT : 4
          },{
            MaDiem :'Diem05',
            MaChuyen : 'CHUYEN01',
            TenDiem : 'Văn phòng Vinh',
            STT : 5
          },{
            MaDiem :'Diem06',
            MaChuyen : 'CHUYEN02',
            TenDiem : 'Thái Bình',
            STT : 1
          },{
            MaDiem :'Diem07',
            MaChuyen : 'CHUYEN02',
            TenDiem : 'Nam Định',
            STT : 2
          },{
            MaDiem :'Diem08',
            MaChuyen : 'CHUYEN02',
            TenDiem : 'Đại lý Rừng và Biển',
            STT : 3
          },{
            MaDiem :'Diem09',
            MaChuyen : 'CHUYEN02',
            TenDiem : 'Văn phòng Thanh Hóa',
            STT : 4
          },{
            MaDiem :'Diem10',
            MaChuyen : 'CHUYEN02',
            TenDiem : 'Văn phòng Vinh',
            STT : 5
          }
        ];
        _.each(DiemDUNG, function(post){
          DiemDung.insert(post);
        });
      }
      //--------------------------------------------------------------------------------------------
      if(Chuyen.find().count() === 0) {
        console.log('Adding Chuyen');
        var CHUYEN=[
          {
            MaChuyen : 'CHUYEN01',
            MaTuyen : 'TUYEN01',
            TenChuyen : 'CHUYEN01',
            DiemDau : 'THÁI BÌNH',
            DiemCuoi : 'VINH'
          },{
            MaChuyen : 'CHUYEN02',
            MaTuyen : 'TUYEN01',
            TenChuyen : 'CHUYEN01',
            DiemDau : 'THÁI BÌNH',
            DiemCuoi : 'VINH'
          },{
            MaChuyen : 'CHUYEN03',
            MaTuyen : 'TUYEN02',
            TenChuyen : 'CHUYEN01',
            DiemDau : 'THÁI BÌNH',
            DiemCuoi : 'QUẢNG NINH'
          },{
            MaChuyen : 'CHUYEN04',
            MaTuyen : 'TUYEN03',
            TenChuyen : 'CHUYEN01',
            DiemDau : 'THÁI BÌNH',
            DiemCuoi : 'HÀ NỘI'
          },{
            MaChuyen : 'CHUYEN05',
            MaTuyen : 'TUYEN04',
            TenChuyen : 'CHUYEN01',
            DiemDau : 'HẢI DƯƠNG',
            DiemCuoi : 'VINH'
          }
        ];
        _.each(CHUYEN, function(post){
          Chuyen.insert(post);
        });
      }
      //------------------------------------------------------------------------------
      if(LaiXe.find().count() === 0) {
        console.log('Adding LaiXe');
        var LAIXE=[
          {
            MaLX :'LX01',
            TenLX : 'NGUYEN VAN A',
            Sdt:'24543214',
            Tuoi:32
          },{
            MaLX :'LX02',
            TenLX : 'NGUYEN VAN B',
            Sdt:'24543214',
            Tuoi:32
          },{
            MaLX :'LX03',
            TenLX : 'NGUYEN VAN C',
            Sdt:'24543214',
            Tuoi:32
          },{
            MaLX :'LX04',
            TenLX : 'NGUYEN VAN D',
            Sdt:'24543214',
            Tuoi:32
          },{
            MaLX :'LX05',
            TenLX : 'NGUYEN VAN E',
            Sdt:'24543214',
            Tuoi:32
          },{
            MaLX :'LX06',
            TenLX : 'NGUYEN VAN F',
            Sdt:'24543214',
            Tuoi:32
          },{
            MaLX :'LX07',
            TenLX : 'NGUYEN VAN G',
            Sdt:'24543214',
            Tuoi:32
          },{
            MaLX :'LX08',
            TenLX : 'NGUYEN VAN H',
            Sdt:'24543214',
            Tuoi:32
          },{
            MaLX :'LX09',
            TenLX : 'NGUYEN VAN I',
            Sdt:'24543214',
            Tuoi:32
          }
        ];

        _.each(LAIXE, function(post){
          LaiXe.insert(post);
        });
      }
        //---------------------------------------------------

        if(Xe_Chuyen.find().count() === 0) {
          console.log('Adding Xe_Chuyen');
        var XE_CHUYEN=[
          {
            Ma:'XECHUYEN01',
            MaXe:'XE01',
            MaChuyen:'CHUYEN01',
            NhanXet:'OK',
            Diem:5
          },{
            Ma:'XECHUYEN02',
            MaXe:'XE02',
            MaChuyen:'CHUYEN01',
            NhanXet:'OK',
            Diem:5
          },{
            Ma:'XECHUYEN03',
            MaXe:'XE03',
            MaChuyen:'CHUYEN01',
            NhanXet:'OK',
            Diem:5
          },{
            Ma:'XECHUYEN04',
            MaXe:'XE04',
            MaChuyen:'CHUYEN02',
            NhanXet:'OK',
            Diem:5
          },{
            Ma:'XECHUYEN05',
            MaXe:'XE05',
            MaChuyen:'CHUYEN02',
            NhanXet:'OK',
            Diem:5
          },{
            Ma:'XECHUYEN06',
            MaXe:'XE06',
            MaChuyen:'CHUYEN03',
            NhanXet:'OK',
            Diem:5
          }
        ];

        _.each(XE_CHUYEN, function(post){
          Xe_Chuyen.insert(post);
        });
      }
//-----------------------------------------------------------------------------------------

      });
