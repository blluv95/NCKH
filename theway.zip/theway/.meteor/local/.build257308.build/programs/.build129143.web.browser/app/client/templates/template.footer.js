(function(){
Template.__checkName("footer");
Template["footer"] = new Template("Template.footer", (function() {
  var view = this;
  return HTML.Raw('<div class="foot">\n    <footer class="footer-boder">\n        <div></div>\n    </footer>\n    <footer class="first-footer">\n        <section class="section-logo"><img class="imgTaxi"></section>\n        <section class="section-address">\n            <div>\n            <h3>NewWay</h3>\n            <p>09.09.876543-09.08.876543<br>\n                <br>\n                Xuân Thủy, Cầu Giấy, Hà Nội<br>\n                NewWay@gmail.com </p>\n            </div>\n        </section>\n        <section class="section-connect">\n            <div>\n            <h3>Connect with us!</h3>\n                <ul>\n                <a href="#"><img src="http://www.w3newbie.com/wp-content/uploads/facebook1.png"></a>\n                <a href="#"><img src="http://www.w3newbie.com/wp-content/uploads/googleplus.png"></a>\n                <a href="#"><img src="http://www.w3newbie.com/wp-content/uploads/twitter1.png"></a>\n                <a href="#"><img src="http://www.w3newbie.com/wp-content/uploads/youtube1.png"></a>\n                </ul>\n            </div>\n        </section>\n    </footer>\n    </div>');
}));

}).call(this);
