(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// routes.js                                                           //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Router.configure({                                                     // 1
    layoutTemplate: 'layout',                                          // 2
    notFoundTemplate: 'notFound',                                      // 3
    loadingTemplate: 'loading'                                         // 4
});                                                                    //
                                                                       //
// #Routes -> Changing the website title                               //
//onAfterAction: function() {                                          //
//    var data = Posts.findOne({slug: this.params.slug});              //
//                                                                     //
//    if(_.isObject(data) && !_.isArray(data))                         //
//        document.title = 'My Meteor Blog - '+ data.title;            //
//    else                                                             //
//        document.title = 'My Meteor Blog - '+ this.route.getName();  //
//}                                                                    //
Router.map(function () {                                               // 18
    this.route('Home', { path: '/', template: 'timkiem' });            // 19
    this.route('Đặt Vé Hót', { path: '/datvehot', template: 'datvehot' });
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);
