(function(){
Template.__checkName("menu");
Template["menu"] = new Template("Template.menu", (function() {
  var view = this;
  return "";
}));

}).call(this);
