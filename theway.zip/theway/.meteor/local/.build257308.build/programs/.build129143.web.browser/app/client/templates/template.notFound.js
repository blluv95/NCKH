(function(){
Template.__checkName("notFound");
Template["notFound"] = new Template("Template.notFound", (function() {
  var view = this;
  return HTML.Raw('<div class="center"><h1>Nothing here</h1><br>\n        <h2>You hit a page which doesn\'t exist!</h2></div>');
}));

}).call(this);
