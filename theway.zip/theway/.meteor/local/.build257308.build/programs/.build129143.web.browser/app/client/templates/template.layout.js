(function(){
Template.__checkName("layout");
Template["layout"] = new Template("Template.layout", (function() {
  var view = this;
  return [ HTML.Raw('<header>\n        <div class="container">\n            <h1>The Way</h1>\n            <ul>\n                <li><a href="/">Trang Chủ</a></li>\n                <li><a href="/about">Xe Khách</a></li>\n                <li><a href="/about">Taxi</a></li>\n                <li><a href="/datvehot">Đặt Vé Hót</a></li>\n                <li><a href="/about">Liên Hệ</a></li>\n            </ul>\n        </div>\n    </header>\n    '), HTML.DIV({
    "class": "contaoner"
  }, "\n        ", HTML.MAIN("\n            ", Spacebars.include(view.lookupTemplate("yield")), "\n        "), "\n    "), "\n", Spacebars.include(view.lookupTemplate("footer")) ];
}));

Template.__checkName("loading");
Template["loading"] = new Template("Template.loading", (function() {
  var view = this;
  return HTML.Raw('<div class="center"><h1>Loading</h1></div>');
}));

}).call(this);
