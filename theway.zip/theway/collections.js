/**
 * Created by BaoADR01 on 3/3/2016.
 */
NhaXe=new Mongo.Collection("nhaxe");  //
Tuyen=new Mongo.Collection("tuyen"); //
Chuyen=new Mongo.Collection("chuyen");//
DiemDung=new Mongo.Collection("diemdung");//
Xe=new Mongo.Collection("xe");
Xe_Chuyen=new Mongo.Collection("xe_chuyen");//
LaiXe=new Mongo.Collection("laixe");//
Taxi=new Mongo.Collection("taxi");
DieuKien=new Mongo.Collection("dieukien");
ChoTrong=new Mongo.Collection("chotrong");
Datve=new Mongo.Collection("datve");
Diemdung_TG=new Mongo.Collection("diemdung_tg");//
